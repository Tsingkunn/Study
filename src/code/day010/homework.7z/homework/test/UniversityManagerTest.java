package code.day010.homework.test;

import code.day010.homework.view.UniversityManager;

public class UniversityManagerTest {
    public static void main(String[] args) {
        new UniversityManager().run();
    }
}
