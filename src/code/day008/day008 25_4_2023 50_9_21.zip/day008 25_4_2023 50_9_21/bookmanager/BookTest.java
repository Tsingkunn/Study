package code.day008.bookmanager;

public class BookTest {
    public static void main(String[] args) {
        new BookManager().run();
    }
}
